<?php
session_start();
$con=mysqli_connect('sql203.epizy.com',"epiz_25367423","l0XNW4tWIL","epiz_25367423_Login");
//echo $con;
$nam=$_POST["name"];
$usr=$_POST["user"];
$pho=$_POST["phone"];
$pass=$_POST["password"];
$year=$_POST["year"];
$college=$_POST["clg"];
$s="select * from login where UserName='$usr' ";

$result=mysqli_query($con,$s);
$num=mysqli_num_rows($result);
if($num==1){
    
    echo '<script type="text/javascript">
          window.onload = function () { alert("UserName already taken please choose another!!!"); }
          </script>';
    
    header( 'refresh:.01;url=\Login\signup.html' );

}
    
else{
    $regi="insert into login values('$nam','$usr','$pass','$pho','','$year','$college')";
    mysqli_query($con,$regi);
    echo '<script type="text/javascript">
          window.onload = function () { alert("Sucessfully registered!!!"); }
          </script>';
    header( 'refresh:.01;url=\index2.html' );
}

?>