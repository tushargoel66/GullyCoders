<?php
session_start();
if(!isset($_SESSION['user'])){
    echo '<script type="text/javascript">
          window.onload = function () { alert("Please login!!!"); }
          </script>';
  header( 'refresh:.01;url=\index2.html' );
}

?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/css/mdb.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="\svg\logo.png"/>
    <title>Congratulations!!!</title>
    
</head>
<body>
   <div class="alert alert-success">
  <strong>Success!</strong>
</div>
<div style="padding-top: 150px;"></div>
      <div  class="animated bounce infinite" alt="Transparent MDB Logo" id="animated-img1"><center><h1>Congratulations <?php session_start(); echo $_SESSION['user'] ?> you have successfully complete C++!!! </h1></center></div>
      <div style="padding-top: 80px;"></div>
        <div style="padding-left: 80px;">
          <div class="row">
            <div class="col">
              <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="\svg\Cppprogram.png" alt="Card image cap">
                <div class="card-body">
                  <h5 class="card-title">JAVA</h5>
                  <p class="card-text">JAVA is a high level language which is used everywhere due to the face that it is extremely simple to use.</p>
                  <a href="\java.php" class="btn btn-primary">Learn Yourself</a>
                </div>
              </div>
            </div>
              <div class="col">
               
        <div class="card" style="width: 18rem;">
          <img class="card-img-top" src="\svg\PSprogram.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Problem Solving</h5>
            <p class="card-text">Problem Solving is a study where a person bulids logic or algorithms by diving a problem into smaller parts.</p>
            <a href="\ps.php" class="btn btn-primary">Learn Yourself</a>
          </div>
        </div>
            </div>

            
        </div>
        </div>


        <div><br><br></div>
<a mdbBtn role="button" class="btn btn-success" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\home.php"><h4>&#8962; Home</h4></a>

<a  mdbBtn role="button"  class="btn btn-success" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\credit.html" target="_blank"><h4>Credits</h4></a>

    <div style="padding-bottom: 50px;"></div>

    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/js/mdb.min.js"></script>
</body>
</html>
