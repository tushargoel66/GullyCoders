<?php
session_start();
$user=$_SESSION['user'];
$con=mysqli_connect("sql203.epizy.com","epiz_25367423","l0XNW4tWIL","epiz_25367423_Login");
$s1="update login set OnlineStatus='0' where UserName='$user'";
mysqli_query($con,$s1);
session_destroy();
echo '<script type="text/javascript">
          window.onload = function () { alert("See you soon!!"); }
          </script>';
    
header('refresh:.01;url=\index2.html');
?>