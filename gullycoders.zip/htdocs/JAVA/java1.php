<?php
session_start();
if(!isset($_SESSION['user'])){
    echo '<script type="text/javascript">
          window.onload = function () { alert("Please login!!!"); }
          </script>';
  header( 'refresh:.01;url=\index2.html' );
}

?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/css/mdb.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="\svg\logo.png"/>
    <title>JAVA Introduction</title>
</head>
<body style="background-color:rgb(209, 239, 243) ">
     <nav class="navbar navbar-expand-lg navbar-dark info-color" >
        <div><img src="\svg\logo.png" class="img-rounded" alt="Cinque Terre" height="40"></div>
        <a class="navbar-brand" href="\home.php">Coders</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">


            <li class="nav-item">
              <a class="nav-link" href="\cpp.php" style="margin-left:60px;"><b>C++</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\java.php" style="margin-left:60px;"><b>JAVA</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\ps.php" style="margin-left:60px;"><b>Problem Solving</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\db.php" style="margin-left:60px;"><b>Database</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\aboutus.php" style="margin-left:60px;"><b>About Us</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\cs.php" style="margin-left:60px;"><b>Contact</b></a>
            </li>
            <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="margin-left:60px;">
          Welcome &nbsp; <font color="black"><?php session_start();  echo $_SESSION['user']; ?></font>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <a class="dropdown-item" href="\Status\FriendsOnline.php">Friends Online</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\Messages\NewChat.php">Chat</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\Login\logout.php">Logout</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\credit.html" target="_blank">Credits</a>
        </div>
      </li>
            
          </ul>
        </div>
      </nav>
      <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Topics
        </button>

       <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="width: 250px;">
        <div style="padding-left:30px">
            <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\JAVA\java0.php">Getting Started</a>
            <div><br></div>
        <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\JAVA\java1.php">Introduction</a>
            <div><br></div>
          <a mdbBtn role="button" color="default" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\JAVA\java2.php">OOPS Concept</a>
          <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\JAVA\java3.php">Inheritance</a>
            <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\JAVA\java4.php">Polymorphism</a>
            <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\JAVA\java5.php">Exception Handling</a>
            <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\JAVA\java6.php">Strings and Methods</a>
            <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\JAVA\java7.php">StringTokenizer</a>
            <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\JAVA\java8.php">Threads</a>
            <div><br></div>
      </div>
    </div>
  </div>
  <h1><center><b>INTRODUCTION</b></center></h1><div><br></div>
  <div style="padding-left:30px" >
    <div style="padding-right: 100px;">
  <h3>&rarr;What is Java</h3>
Java is a programming language and a platform. Java is a high level, robust, object-oriented and secure programming language.
Java was developed by Sun Microsystems (which is now the subsidiary of Oracle) in the year 1995.
<b><i>James Gosling</i></b> is known as the father of Java. Before Java, its name was Oak.
Since Oak was already a registered company, so James Gosling and his team changed the Oak name to Java.
<div><br></div>
<b>Platform:</b> Any hardware or software environment in which a program runs, is known as a platform.
Since Java has a runtime environment (JRE) and API, it is called a platform.
      <div><br></div>
      <div><h3>&rarr;Editions of JAVA</h3></div>
     <div> JAVA is mainly available in three editions :</div>
     1. J2SE (Standard Edition) &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 2. J2EE (Enterprise Edition)
     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 3. J2ME (Mobile/Micro Edition)
     <div><br></div>
     <div><h5>&nbsp;&#8226; Standard Edition</h5></div>
     <div style="padding-left:50px">&mdash;Mainly covers the fundamentalc concepts of JAVA.<br>
    &mdash;Core JAVA like Inheritance, Polymorphism, Interfaces and many more. <br>
  &mdash; It is mainly used for standalone application.<br>
&mdash; Standalone applications are nothing but we can ececute that in only in the local machine and standalone application doesn't
involves client server architecture. It means it invloves only client application.<br><br></div>
  <div><h5>&nbsp;&#8226; Enterprise Edition</h5></div>
  <div style="padding-left:50px">&mdash; It mainly covers advanced concepts of the JAVA like servelets, JSP.<br>
  &mdash; It is mainly used for the client server architecture.<br><br></div>
  <div><h5>&nbsp;&#8226; Mobile/Micro Edition</h5></div>
    <div style="padding-left:50px">It is useful in order to devlop mobile application.</div>
<div><br><br></div>
<a mdbBtn role="button" class="btn btn-success" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\JAVA\java0.php">&larr; Pervious </a>
<a mdbBtn role="button" class="btn btn-success" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\JAVA\java2.php">Next &rarr;</a>
<div style="padding-bottom: 50px;"></div>
</div>
</div>
    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/js/mdb.min.js"></script>
</body>
</html>
