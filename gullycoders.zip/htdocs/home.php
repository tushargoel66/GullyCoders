<?php
session_start();
if(!isset($_SESSION['user'])){
    echo '<script type="text/javascript">
          window.onload = function () { alert("Please login!!!"); }
          </script>';
  header( 'refresh:.01;url=\index2.html' );
}

?>
<!doctype html>

<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/css/mdb.min.css" rel="stylesheet">
    <link rel="icon" type="image" href="\svg\logo.png"/>
    <title>Home</title>

</head>
<body style="background-color:rgb(120, 214, 221) ">
     <nav class="navbar navbar-expand-lg navbar-dark info-color" >
        <div><img src="\svg\logo.png" class="img-rounded" alt="Cinque Terre" height="40"></div>
        <a class="navbar-brand" href="\home.php">Coders</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">


            <li class="nav-item">
              <a class="nav-link" href="\cpp.php" style="margin-left:60px;"><b>C++</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\java.php" style="margin-left:60px;"><b>JAVA</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\ps.php" style="margin-left:60px;"><b>Problem Solving</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\db.php" style="margin-left:60px;"><b>Database</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\aboutus.php" style="margin-left:60px;"><b>About Us</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\cs.php" style="margin-left:60px;"><b>Contact</b></a>
            </li>
            <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="margin-left:60px;">
          Welcome &nbsp; <font color="black"><?php session_start();  echo $_SESSION['user']; ?></font>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <a class="dropdown-item" href="\Status\FriendsOnline.php">Friends Online</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\Messages\NewChat.php">Chat</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\Login\logout.php">Logout</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\credit.html" target="_blank">Credits</a>
        </div>
      </li>
            
          </ul>
        </div>
      </nav>

      <div style="padding-top: 100px;"></div>
      <div  class="animated bounce infinite" alt="Transparent MDB Logo" id="animated-img1"><center><h1>WELCOME!!</h1></center></div>
      <div style="padding-top: 80px;"></div>
        <div style="padding-left: 80px;">
          <div class="row">
            <div class="col">
              <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="\svg\Cppprogram.png" alt="Card image cap">
                <div class="card-body">
                  <h5 class="card-title">C++</h5>
                  <p class="card-text">The basic language used to devlope program and is easy to start and work with.</p>
                  <a href="\cpp.php" class="btn btn-primary">Learn Yourself</a>
                </div>
              </div>
            </div>
              <div class="col">
                <div class="card" style="width: 18rem;">
                  <img class="card-img-top" src="\svg\JAVAprogram.png" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">JAVA</h5>
                    <p class="card-text">JAVA is a high level language which is used everywhere due to the face that it is extremely simple to use.</p>
                    <a href="\java.php" class="btn btn-primary">Learn Yourself</a>
                  </div>
                </div>
            </div>

            <div class="col">
              <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="\svg\SQLprogram.png" alt="Card image cap">
                <div class="card-body">
                  <h5 class="card-title">DataBase</h5>
                  <p class="card-text">Databases can be used everywhere ranging from website to storing student information in a school or a  college.</p>
                  <a href="\db.php" class="btn btn-primary">Learn Yourself</a>
                </div>
              </div>
          </div>
        </div>
        </div>

        <div style="padding-bottom: 20px;"></div>
        <div style="padding-left: 485px;">
          <div class="row">
            <div class="col">
        <div class="card" style="width: 18rem;">
          <img class="card-img-top" src="\svg\PSprogram.png" alt="Card image cap">
          <div class="card-body">
            <h5 class="card-title">Problem Solving</h5>
            <p class="card-text">Problem Solving is a study where a person bulids logic or algorithms by diving a problem into smaller parts.</p>
            <a href="\ps.php" class="btn btn-primary">Learn Yourself</a>
          </div>
        </div>
    </div>
  </div>
</div>
    <div style="padding-bottom: 50px;"></div>


    

     

    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/js/mdb.min.js"></script>
</body>
</html>
