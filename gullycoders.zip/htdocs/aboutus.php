<?php
session_start();
if(!isset($_SESSION['user'])){
    echo '<script type="text/javascript">
          window.onload = function () { alert("Please login!!!"); }
          </script>';
  header( 'refresh:.01;url=\index2.html' );
}

?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/css/mdb.min.css" rel="stylesheet">
    <link rel="icon" type="image" href="\svg\logo.png"/>
    <title>About</title>
</head>



<body style="background-color:rgb(184, 242, 250) ">
     <nav class="navbar navbar-expand-lg navbar-dark info-color" >
        <div><img src="\svg\logo.png" class="img-rounded" alt="Cinque Terre" height="40"></div>
        <a class="navbar-brand" href="\home.php">Coders</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">


            <li class="nav-item">
              <a class="nav-link" href="\cpp.php" style="margin-left:60px;"><b>C++</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\java.php" style="margin-left:60px;"><b>JAVA</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\ps.php" style="margin-left:60px;"><b>Problem Solving</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\db.php" style="margin-left:60px;"><b>Database</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\aboutus.php" style="margin-left:60px;"><b>About Us</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\cs.php" style="margin-left:60px;"><b>Contact</b></a>
            </li>
            <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="margin-left:60px;">
          Welcome &nbsp; <font color="black"><?php session_start();  echo $_SESSION['user']; ?></font>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
        <a class="dropdown-item" href="\Status\FriendsOnline.php">Friends Online</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\Messages\NewChat.php">Chat</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\Login\logout.php">Logout</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\credit.html" target="_blank">Credits</a>
        </div>
      </li>
            
          </ul>
        </div>
      </nav>
      <div class="txt" style="padding-top:200px"></div>
      <center><b><h1>#WHOAREWE</h1></b></center>
      <div class="txt" style="padding-top:50px"></div>
      <div style="background-color: rebeccapurple ">
      <div class="txt" style="padding-top:50px"></div>
      <font color="white"><center><b><h3>About</h3></b></center></font>
      <div class="txt" style="padding-top:50px"></div>
      <div class="txt" style="padding-left:600px">

      <font size="6" color="white"><b>Where have we come from? What is our History?</font></b>
      <div><br></div>
      <font size="4" color="white">In 2020's,we being students faced a few issues to think in a logical way. We needed a mentor who could polish us for tremendous results. We observed many more are lacking in the same direction i.e 'Thinking Smarter'.
      Who will not wish to get succeed with fruitful results. Here it was all started, for the development of IT sector, clear-sighted employees are high in requirement.
      Let us code together and get accepted in lifes. </font><div><br></div>
      </div >
      <div  style="padding-left:45px">
      <font size="6" color="white"><b>Who we serve?</font></b>
      <div><br></div>

      <div  style="padding-right:700px">
      <font size="4" color="white">Students who are really intersted in coding but couldn't reach the sky, trust us you have got into the best platform. Students who had setup sky as their limits are benefited for sure.Here, in Coders, there will be blend of both smart and hard work to become world-class coders. Once you are into it, you'll find yourselves in top-of-the-line.</font></b>
      </div>
      <div  style="padding-bottom:70px"></div>
      <div class="txt" style="padding-left:600px">
      <font size="6" color="white"><b>Mission and Vission?</font></b>
      <div><br></div>
      <font size="4" color="white">We are on our journey to toggle the difficulties and overcome them. We ensure that you face your interviews with atmost confidence. Coding is not just to run and execute, its all about logics and excellence. We are here to resolve any issue in your way of thinking and help you out productively. We support you that you can win your battle with your own skills.  </font>
      <div></div>
      </div>


      <div style="padding-top: 80px;"></div>

          <div class="row">

            <div class="col">
              <div style="margin-left: 180px;">
              <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="\svg\creator1.jpg" alt="Card image cap">
                <div class="card-body">
                  <h5 class="card-title">VANDANA GOPARAJU</h5>
                  <p class="card-text">Vandana has a bachelor's degree in ECE from CMR Enigineering College. She is person who belive in learing is a never ending process.</p>
                </div>
              </div>
            </div>
          </div>

            <div style="margin-right: 190px;">
              <div class="col">
                <div class="card" style="width: 18rem;">
                  <img class="card-img-top" src="\svg\creator2.jpg" alt="Card image cap">
                  <div class="card-body">
                    <h5 class="card-title">TUSHAR GOEL</h5>
                    <p class="card-text">Tushar has got his batchelor's degree in ECE form CMR Enigineering College. He is defined by his quality of learing new things in depth.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div style="padding-bottom: 30px;"></div>
      </div>


    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/js/mdb.min.js"></script>
</body>
</html>
