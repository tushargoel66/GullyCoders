<?php
     session_start();
        $user=$_SESSION['user'];  
        $con=mysqli_connect("sql203.epizy.com","epiz_25367423","l0XNW4tWIL","epiz_25367423_Login");
        $sh="delete from messages where FromID='$user' ";
        $res=mysqli_query($con,$sh);
        echo "Done!!!";
        header('refresh: 2;url=\Messages\NewChat.php');
    ?>