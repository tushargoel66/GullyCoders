 <?php
    session_start();
    $con=mysqli_connect("sql203.epizy.com","epiz_25367423","l0XNW4tWIL","epiz_25367423_Login");
    $user=$_SESSION['user'];  
    $to=$_POST['touser'];
    $me=$_POST['mess'];
    $vali="select * from login where UserName ='$to' ";
    $res=mysqli_query($con,$vali);
    $num=mysqli_num_rows($res);
    if(isset($_POST['submit'])){
        if($num==1&&$user!=$to){  
          $regi="insert into messages values('$user','$to','$me')";
            mysqli_query($con,$regi);
            header( 'location:\Messages\NewChat.php' );
        }
        else{
            if($user==$to){
                echo '<script type="text/javascript">
          window.onload = function () { alert("Sender and Receiver UserName cant be same!!!"); }
          </script>';
          header( 'refresh:.01;url=\Messages\NewChat.php' );
            }
            else{
            echo '<script type="text/javascript">
          window.onload = function () { alert("Enter a valid receiver Username!!"); }
          </script>';
          header( 'refresh:.01;url=\Messages\NewChat.php' );
            }
        }
    }
    
?>