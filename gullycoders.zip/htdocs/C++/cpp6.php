<?php
session_start();
if(!isset($_SESSION['user'])){
echo '<script type="text/javascript">
          window.onload = function () { alert("Please login!!!"); }
          </script>';
header( 'refresh:.01;url=\index2.html' );}
?>
<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
    <!-- Bootstrap core CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <!-- Material Design Bootstrap -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/css/mdb.min.css" rel="stylesheet">
    <link rel="icon" type="image/png" href="\svg\logo.png"/>
    <title>Classes and Objects</title>
</head>

   

<body style="background-color:rgb(209, 239, 243) ">
    <nav class="navbar navbar-expand-lg navbar-dark info-color" >
        <div><img src="\svg\logo.png" class="img-rounded" alt="Cinque Terre" height="40"></div>
        <a class="navbar-brand" href="\home.php">Coders</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">


            <li class="nav-item">
              <a class="nav-link" href="\cpp.php" style="margin-left:60px;"><b>C++</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\java.php" style="margin-left:60px;"><b>JAVA</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\ps.php" style="margin-left:60px;"><b>Problem Solving</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\db.php" style="margin-left:60px;"><b>Database</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\aboutus.php" style="margin-left:60px;"><b>About Us</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="\cs.php" style="margin-left:60px;"><b>Contact</b></a>
            </li>

            <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="margin-left:60px;">
          Welcome &nbsp; <font color="black"><?php session_start();  echo $_SESSION['user']; ?></font>
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="\Login\logout.php">Logout</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="\credit.html" target="_blank">Credits</a>
        </div>
      </li>
            
            
          </ul>
        </div>
      </nav>
     <div class="dropdown">
      <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
        Topics
      </button>
      
      <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" style="width: 250px;">
        <div style="padding-left:30px">
        <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\C++\cpp0.php">Getting Started</a>
        <div><br></div>
        <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\C++\cpp1.php">Introduction</a>
            <div><br></div>
          <a mdbBtn role="button" color="default" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\C++\cpp2.php">Functions</a>
          <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\C++\cpp3.php">Arrays</a>
            <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\C++\cpp4.php">Strings</a>
            <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\C++\cpp5.php"> Pointers and References</a>
            <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\C++\cpp6.php">Classes and Objects</a>
            <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\C++\cpp7.php">Templetes</a>
            <div><br></div>
          <a mdbBtn role="button" color="primary" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\C++\cpp8.php">Files and Streams</a>
            <div><br></div>
      </div>
    </div>
  </div>



  <div><br><br></div>
<a mdbBtn role="button" class="btn btn-success" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\C++\cpp5.php">&larr; Pervious </a>
<a mdbBtn role="button" class="btn btn-success" size="lg" class="active" aria-pressed="true" mdbWavesEffect href="\C++\cpp7.php">Next &rarr;</a>
<div style="padding-bottom: 50px;"></div>
    <!-- JQuery -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <!-- Bootstrap tooltips -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.4/umd/popper.min.js"></script>
    <!-- Bootstrap core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.4.1/js/bootstrap.min.js"></script>
    <!-- MDB core JavaScript -->
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdbootstrap/4.13.0/js/mdb.min.js"></script>
</body>
</html>